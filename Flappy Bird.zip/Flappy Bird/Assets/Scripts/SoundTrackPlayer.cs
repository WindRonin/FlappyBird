using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundTrack : MonoBehaviour
{
    public AudioClip[] Soundtracks;
    AudioSource AS;
    
    void Start()
    {
        AS = GetComponent<AudioSource>();
    }

    
    void Update()
    {
        if(AS.isPlaying == false)
        {
            int HistoryID = 0;
            int SoundtrackID;
            SoundtrackID = Soundtracks.Length - 1;

            if(SoundtrackID != HistoryID)
            {
                AS.clip = Soundtracks[Random.Range(0, SoundtrackID)];
                    
                AS.Play();

                HistoryID = SoundtrackID;
            }
            
        }
    }
}
